require('dotenv').config();
const { Client, IntentsBitField, EmbedBuilder, ActivityType, PermissionsBitField, AuditLogEvent } = require('discord.js');
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const path = require('path');

// ========= إعداد التطبيق =========
const app = express();
const PORT = process.env.PORT || 3000;
const client = new Client({
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildModeration,
        IntentsBitField.Flags.GuildInvites,
        IntentsBitField.Flags.GuildWebhooks,
        IntentsBitField.Flags.GuildIntegrations
    ]
});

// ========= الإعدادات =========
const config = {
    prefix: process.env.BOT_PREFIX || '!sec ',
    ownerId: process.env.OWNER_ID || '622759685228986384',
    whitelistRoleName: '🛡️ WhiteList',
    maxKicksBeforeBan: 3,
    nukeProtection: true,
    maxChannels: 50,
    footer: {
        text: 'Dev By Boda',
        iconURL: process.env.FOOTER_IMAGE_URL || 'https://imgur.com/a/eHp5PZx.png'
    }
};

// ========= قواعد البيانات المؤقتة =========
const data = {
    whitelistedUsers: new Set(),
    userViolations: new Map(),
    protectedRoles: new Set()
};

// ========= Middleware =========
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: process.env.NODE_ENV === 'production' }
}));
app.use(passport.initialize());
app.use(passport.session());

// ========= تكوين Passport =========
passport.use(new DiscordStrategy({
    clientID: process.env.DISCORD_CLIENT_ID,
    clientSecret: process.env.DISCORD_CLIENT_SECRET,
    callbackURL: process.env.CALLBACK_URL || 'http://localhost:3000/auth/discord/callback',
    scope: ['identify', 'guilds']
}, (accessToken, refreshToken, profile, done) => {
    return done(null, profile);
}));

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

// ========= إعداد محرك العرض =========
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ========= Routes =========
app.get('/', (req, res) => res.render('index'));
app.get('/dashboard', (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/');
    
    res.render('dashboard', { 
        user: req.user,
        bot: client,
        guilds: client.guilds.cache,
        config: config
    });
});

app.get('/auth/discord', passport.authenticate('discord'));
app.get('/auth/discord/callback', passport.authenticate('discord', {
    failureRedirect: '/'
}), (req, res) => res.redirect('/dashboard'));

app.get('/logout', (req, res) => {
    req.logout();
    res.redirect('/');
});

// ========= واجهة API =========
app.get('/api/stats', async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ error: 'Unauthorized' });

    try {
        const guilds = client.guilds.cache;
        res.json({
            bot: {
                username: client.user.username,
                avatar: client.user.displayAvatarURL(),
                uptime: process.uptime(),
                ping: client.ws.ping
            },
            guilds: guilds.size,
            users: guilds.reduce((a, g) => a + g.memberCount, 0),
            commands: 24,
            whitelistedUsers: Array.from(data.whitelistedUsers)
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ========= وظائف البوت المساعدة =========
async function setupWhitelistRole(guild) {
    let role = guild.roles.cache.find(r => r.name === config.whitelistRoleName);
    if (!role) {
        role = await guild.roles.create({
            name: config.whitelistRoleName,
            color: '#00ff00',
            permissions: [],
            reason: 'إنشاء دور الوايت ليست'
        });
        console.log(`تم إنشاء دور الوايت ليست: ${role.name}`);
    }
    return role;
}

function sendEmbed(channel, title, description, color, fields = []) {
    const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setFooter(config.footer);
    
    if (fields.length > 0) embed.addFields(fields);
    channel.send({ embeds: [embed] });
}

// ========= أحداث البوت =========
client.on('ready', async () => {
    console.log(`✅ ${client.user.tag} يعمل الآن!`);
    client.user.setActivity({
        name: 'Dev By Boda',
        type: ActivityType.Watching
    });

    // إعداد دور الوايت ليست في كل سيرفر
    client.guilds.cache.forEach(async guild => {
        await setupWhitelistRole(guild);
    });

    // بدء خادم الويب بعد اكتمال تحميل البوت
    app.listen(PORT, () => {
        console.log(`🚀 Dashboard running on http://localhost:${PORT}`);
    });
});

// ========= أنظمة الحماية =========
client.on('channelCreate', async channel => {
    if (config.nukeProtection && channel.guild.channels.cache.size > config.maxChannels) {
        await channel.delete().catch(console.error);
        sendEmbed(
            channel.guild.systemChannel,
            '🚨 اكتشاف محاولة تخريب (Nuke)',
            'تم اكتشاف إنشاء قنوات بشكل مريب وتم إيقافه',
            '#ff0000'
        );
    }
});

client.on('guildMemberRemove', async member => {
    const auditLogs = await member.guild.fetchAuditLogs({
        type: AuditLogEvent.MemberKick,
        limit: 1
    });
    const executor = auditLogs.entries.first()?.executor;

    if (executor) {
        const violations = data.userViolations.get(executor.id) || 0;
        data.userViolations.set(executor.id, violations + 1);

        if (violations >= config.maxKicksBeforeBan) {
            await member.guild.members.ban(executor, { reason: 'طرد جماعي' });
            sendEmbed(
                member.guild.systemChannel,
                '⛔ تم حظر مخرب',
                `تم حظر ${executor.tag} بسبب طرد ${violations + 1} أعضاء`,
                '#ff0000'
            );
        }
    }
});

client.on('roleUpdate', async (oldRole, newRole) => {
    if (newRole.permissions.has(PermissionsBitField.Flags.Administrator)) {
        const auditLogs = await newRole.guild.fetchAuditLogs({
            type: AuditLogEvent.RoleUpdate,
            limit: 1
        });
        const executor = auditLogs.entries.first()?.executor;

        if (executor && executor.id !== client.user.id) {
            await newRole.edit({ permissions: [] }).catch(console.error);
            sendEmbed(
                newRole.guild.systemChannel,
                '⚠️ تحذير: تعديل خطير على الأدوار',
                `تم تعديل دور ${newRole.name} ليمنح صلاحيات إدارية وتم إيقافه`,
                '#ff9900',
                [
                    { name: 'المعدل', value: executor.tag },
                    { name: 'الإجراء', value: 'تم إزالة الصلاحيات الخطيرة' }
                ]
            );
        }
    }
});

client.on('messageCreate', async message => {
    if (message.author.bot) return;

    // نظام حماية الروابط الضارة
    const maliciousLinks = ['discord.gg/', 'nitro.', 'steamcommunity.com'];
    if (maliciousLinks.some(link => message.content.includes(link))) {
        await message.delete();
        sendEmbed(
            message.channel,
            '⚠️ تحذير أمني',
            `تم اكتشاف رابط ضار من ${message.author}`,
            '#ff0000',
            [
                { name: 'الرسالة', value: message.content },
                { name: 'الإجراء', value: 'تم حذف الرسالة وتنبيه الإدارة' }
            ]
        );
    }

    // نظام الأوامر
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    const isWhitelisted = data.whitelistedUsers.has(message.author.id) || message.author.id === config.ownerId;
    const isAdmin = message.member.permissions.has(PermissionsBitField.Flags.Administrator);

    // أوامر الإدارة
    if (command === 'ban' && isWhitelisted) {
        const user = message.mentions.users.first();
        if (user) {
            const reason = args.slice(1).join(' ') || 'بدون سبب';
            await message.guild.members.ban(user, { reason });
            
            sendEmbed(
                message.channel,
                '🔨 تم الحظر',
                `تم حظر ${user.tag}`,
                '#ff0000',
                [
                    { name: 'السبب', value: reason },
                    { name: 'بواسطة', value: message.author.tag }
                ]
            );
        }
    }

    // يمكنك إضافة المزيد من الأوامر هنا
});

// ========= تشغيل البوت =========
client.login(process.env.DISCORD_BOT_TOKEN);